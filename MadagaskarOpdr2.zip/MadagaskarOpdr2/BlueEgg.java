import greenfoot.*;

/**
 * Write a description of class BlueEgg here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BlueEgg extends Egg
{
    public BlueEgg () {
        super( 1 );
    }    
}
