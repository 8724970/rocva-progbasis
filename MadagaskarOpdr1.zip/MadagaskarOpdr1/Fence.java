import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Fence here.
 * 
 * @author Sjaak Smetsers
 * @version 13-07-2011
 */
public class Fence extends Actor
{
}
